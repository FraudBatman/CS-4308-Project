'''
Created on May 17, 2011

@author: dgayler
'''

class DivisionByZeroException (Exception):
    pass