public class DivisionByZeroException extends RuntimeException
{

	private static final long serialVersionUID = -9173626247497678343L;

	public DivisionByZeroException (String message)
	{
		super (message);
	}
	
}
