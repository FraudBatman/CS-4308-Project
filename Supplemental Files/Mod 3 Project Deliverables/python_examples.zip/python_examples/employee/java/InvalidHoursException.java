public class InvalidHoursException extends Exception
{

	public InvalidHoursException (String message)
	{
		super (message);
	}
	
}
