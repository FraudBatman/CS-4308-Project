'''
Created on Jun 27, 2011

@author: dgayler
'''

class InvalidDateException(Exception):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        