'''
Created on Jun 27, 2011

@author: dgayler
'''

class InvalidHoursException (Exception):
    
    
    def __init__(self):
        '''
        Constructor
        '''
